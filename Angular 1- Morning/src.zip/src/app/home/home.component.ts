import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  nameCount: number=4;
  btnText: string="Add a name";
  nameText: string="snigdha";
  names: string[]=[];
  constructor() { }

  ngOnInit(): void {
    this.nameCount=this.names.length;
  }
  addName(){
this.names.push(this.nameText);
this.nameText='';
this.nameCount=this.names.length;
  }
OnWrite(event: any){
  this.names=event.target.names;
}
  
}
