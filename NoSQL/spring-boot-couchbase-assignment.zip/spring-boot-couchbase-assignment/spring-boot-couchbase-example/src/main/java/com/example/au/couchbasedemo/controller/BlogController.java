package com.example.au.couchbasedemo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.au.couchbasedemo.model.Blogs;
import com.example.au.couchbasedemo.repository.BlogRepository;

@RestController
public class BlogController {
    
    @Autowired
    BlogRepository blogRepository;
    
	/*
	 * @RequestMapping("/") public String index() { return
	 * "Welcome to the CRUD application!!"; }
	 */
    
    @PostMapping("/blogs")
    public Blogs addBlogPost(@RequestBody Blogs newBlog) {
        return blogRepository.save(newBlog);
    }
    
    @GetMapping("/blogs/{id}")
    public Optional<Blogs> getBlog(@PathVariable String id) {
        if (blogRepository.existsById(id)) {
            return blogRepository.findById(id);
        } else
            return Optional.empty();
    }
    
    @GetMapping("/blogs/goals/{goals}")
    public Blogs getBlogBygoals(@PathVariable String goals) {
        return blogRepository.findBygoals(goals);
    }
    
    @DeleteMapping("/blogs/playerName/{playerName}/goals/{goals}")
    public List<Blogs> deleteByplayerNameAndgoals(@PathVariable String playerName, @PathVariable String goals) {
        return blogRepository.deleteByplayerNameAndgoals(playerName, goals);
    }
    
    @DeleteMapping("/blogs/{id}")
    public void deleteById(@PathVariable String id) {
        blogRepository.deleteById(id);
    }

    @GetMapping("/blogs/teams/{teams}")
    public List<Blogs> getBlogByteams(@PathVariable List<String> teams) {
        List<Blogs> blogsList=new ArrayList<>();
       blogRepository.findAll().forEach(Blogs->{
           List<String> teamsInBlog=Blogs.getteams();
           for(String s:teams)
           {
               if(teamsInBlog.contains(s))
               {
                   blogsList.add(Blogs);
                   break;
               }
           }
       });


            return blogsList;
    }

}