package com.example.au.couchbasedemo.model;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.Field;

import com.sun.istack.NotNull;

@Document
public class Blogs {
    
    @Id
    String id;
    
    @NotNull
    @Field
    String playerName;
    
    @NotNull
    @Field
    String goals;
    
    @Field
    List<String> teams;
    
   // @Field
    //Date DateOfJoining;

	public String getplayerName() {
		return playerName;
	}

	public void setplayerName(String playerName) {
		this.playerName = playerName;
	}

	public String getgoals() {
		return goals;
	}

	public void setgoals(String goals) {
		this.goals = goals;
	}

	public List<String> getteams() {
		return teams;
	}

	public void setteams(List<String> teams) {
		this.teams = teams;
	}

	//public Date getDateOfJoining() {
		//return DateOfJoining;
	//}

	//public void setDateOfJoining(Date DateOfJoining) {
		//this.DateOfJoining = DateOfJoining;
	//}

	public String getId() {
		return id;
	}

	public Blogs(String id, String playerName, String goals, List<String> teams) {
		super();
		this.id = id;
		this.playerName = playerName;
		this.goals = goals;
		this.teams = teams;
		//this.DateOfJoining = DateOfJoining;
	}
    
    
    
}
