import React from 'react';


const Contact =() => {
    return (
        <div className="container">
            <div className="py-4">
             <h1>Contact Us</h1>   
            </div>
        </div>
    );
};

export default Contact;