import axios from 'axios';
import React , { useState} from 'react';
import {useHistory} from 'react-router-dom';
const AddBook = () => {

    let history= useHistory();
    const [ user, setUser] =useState ({
        id:"",
        name:"",
        author:"",
        price:""
    });
    const {name,author,price}= user ;
    const onInputChange = e => {
        setUser({[e.target.name]: e.target.value})
    };
    const onSubmit = async e => {
        e.preventDefault();
        await axios.post("http://localhost:3333/users",user);
        history.push("/");
    };
    return (
        <div className="container">
         <div className="w-75 mx-auto shadow p-5">
             <h2 className="text-center mb-4">Add a Book</h2>

                <form onSubmit={e => onSubmit(e)}>
                <div className="form-group">
                <input type="text" className="form-control form-control-lg" placeholder="Enter name of book" name="name" value={name} onChange={e => onInputChange(e)} />
                </div>

                <div className="form-group">
                <input type="text" className="form-control form-control-lg" placeholder="Enter author name" name="author" value={author} onChange={e => onInputChange(e)} />  
                </div>

                <div className="form-group">
                <input type="text" className="form-control form-control-lg" placeholder="Enter price" name="price" value={price} onChange={e => onInputChange(e)} />  
                </div>
                <button className="btn btn-primary btn-block">Add Book </button>
                </form>

             </div>   
        </div>
    )
}

export default AddBook ;